    <div class="footer_top_area">
    <div class="footer_bottom_area">
      <div class="copyright_text">
        <p>Lê Đức Phúc</p>
        <p>Contact: 0378475757</p>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript" src="/templates/aboutme/assets/js/bootstrap.min.js"></script> 
<script type="text/javascript" src="/templates/aboutme/assets/js/jquery.bxslider.js"></script> 
<script type="text/javascript" src="/templates/aboutme/assets/js/selectnav.min.js"></script> 
<script type="text/javascript">
selectnav('nav', {
    label: '-Navigation-',
    nested: true,
    indent: '-'
});
selectnav('f_menu', {
    label: '-Navigation-',
    nested: true,
    indent: '-'
});
$('.bxslider').bxSlider({
    mode: 'fade',
    captions: true
});
</script>
</body>
</html>
<?php
    ob_end_flush();
?>