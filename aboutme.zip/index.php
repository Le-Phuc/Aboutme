<?php include_once $_SERVER['DOCUMENT_ROOT'].'/templates/aboutme/inc/header.php'; ?>


    <div class="content_area">
      <div class="main_content">
          <div class="toilaai">
            <h2 class="title">Tôi là ai...?</h2>
            <img src="files/toilaai.jpg" alt="" class="tla"/>
              <p>Tôi từng thi đậu vào một ngôi trường quân đội vào năm 2018, nhưng vì cảm thấy bản thân không thích hợp với môi trường quân dội nên tôi đã ra quân và về học tập tạo trường Cao đẳng CNTT-ĐHĐN. Trong quá trình học tập tôi mải mê chơi bời dẫn đến mất gốc về lập trình. khi biết đến trung tâm đào tạo lập trình viên VinaENTER tôi đã đăng kí ngay lập tức để thử sức lại với ngành lập trình viên. Mong muốn của tôi là trở thành một Web Developer.</p>
          </div>
          <div class="clr"></div>

           <div class="toilaai">
            <h2 class="title">Thông tin về tôi</h2>
            <img src="files/thongtin.jpg" alt="" class="tla"/>
            <ul class="ultt">
              <li>Ngày sinh: 28/01/2000</li>
              <li>Số điện thoại: +84 378475757</li>
              <li>Địa chỉ: Phường 3 - TX Quảng Trị - Quảng Trị</li>
              <li>E-mail: leducphuc2000@gmail.com</li>
            </ul>
          </div>
          <div class="clr"></div>

          <div class="changduong">
            <h2 class="title">Chặng đường đã qua</h2>
            <div class="sqtt"> 
              <img src="files/sqtt.jpg" width="200px"/>
              <h3>08-2018</h3>
              <p>Trường sĩ quan thông tin</p>
            </div>

            <div class="sqtt">
             <img src="files/cntt.jpg" width="200px"/>
              <h3>09-2018</h3>
              <p>Trường cao đẳng CNTT-ĐHĐN</p>
               </div>

            <div class="sqtt"> 
              <img class="vina" src="files/vinaenter.jpg"alt="" width="200px"/>
              <h3>04-2021</h3>
              <p>Trung tâm đào tạo lập trình viên VinaEnter</p>
            </div>
          </div>
      </div>
    </div>

<?php require_once $_SERVER['DOCUMENT_ROOT'].'/templates/aboutme/inc/footer.php'; ?>

